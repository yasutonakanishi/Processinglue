/**
 * In order to show a PApplet in a PGlueDisplay as a content, the parent 3D PApplet create the instance of the content PAppet and controls the thread.
 * Thus, the content PApplet should inherit this class to run within the parent 3D PApplet.
 * A sample of a PApplet that runs another PApplet can be found at https://github.com/yasutonakanishi/MultiplePApplet 
 * @author Yasuto Nakanishi
 */

package net.unitedfield.processinglue;

import processing.core.*;

public class ContentPApplet extends PApplet {

	public ContentPApplet(int _width, int _height) {
		super();
		PSurface surface = super.initSurface(); // init surface
		surface.setSize(_width, _height);
		surface.setVisible(true);
		surface.startThread();
	}
}