/**
 * Frustum of a virtual camera to show the location and direction.
 * @author Yasuto Nakanishi
 */
package net.unitedfield.processinglue;

import processing.core.PVector;
import processing.opengl.PGraphics3D;

public class PglueFrustum {
	PVector loc, lookAt, dir;
	float near, width, height;

	/**
	 * Constructor	
	 * @param _loc location of the parent camera
	 * @param _lookAt direction of the parent camera
	 * @param cameraGraphics PGraphics3D to capture by the parent virtual camera
	 */
	public PglueFrustum(PVector _loc, PVector _lookAt, PGraphics3D cameraGraphics) {
		loc = new PVector(_loc.x, _loc.y, _loc.z);
		lookAt = new PVector(_lookAt.x, _lookAt.y, _lookAt.z);
		dir = new PVector();

		this.near = cameraGraphics.cameraNear;
		this.height = (float) (this.near * (Math.sin(cameraGraphics.cameraFOV / 2)) * 2);
		this.width = this.height * cameraGraphics.cameraAspect;
	}

	/**
	 * set the location 
	 * @param _x x of the location
	 * @param _y y of the location
	 * @param _z z of the location
	 */
	public void setLocation(float _x, float _y, float _z) {
		this.loc.x = _x;
		this.loc.y = _y;
		this.loc.z = _z;
	}

	/**
	 * set the lookAt 
	 * @param _x
	 * @param _y
	 * @param _z
	 */
	public void setLookAt(float _x, float _y, float _z) {
		this.lookAt.x = _x;
		this.lookAt.y = _y;
		this.lookAt.z = _z;
	}

	/**
	 * draw the frustum to a specified PGraphics3D 
	 * @param dstg the destination PGraphics3D
	 */
	public void draw(PGraphics3D dstg) {
		dstg.pushMatrix();
		dstg.translate(loc.x, loc.y, loc.z);
		dstg.sphere(10);

		dir.x = lookAt.x - loc.x;
		dir.y = lookAt.y - loc.y;
		dir.z = lookAt.z - loc.z;
		double yAxisRot = Math.atan2((double) dir.x, (double) dir.z);
		double xAxisRot = Math.atan2(-(double) dir.y, (Math.sqrt(dir.x * dir.x + dir.z * dir.z)));
		dstg.rotateY((float) yAxisRot);
		dstg.rotateX((float) xAxisRot);

		dstg.beginShape();// draw pyramid
		dstg.vertex(-width / 2, -height / 2, near);
		dstg.vertex(width / 2, -height / 2, near);
		dstg.vertex(0, 0, 0);

		dstg.vertex(width / 2, -height / 2, near);
		dstg.vertex(width / 2, height / 2, near);
		dstg.vertex(0, 0, 0);

		dstg.vertex(width / 2, height / 2, near);
		dstg.vertex(-width / 2, height / 2, near);
		dstg.vertex(0, 0, 0);

		dstg.vertex(-width / 2, height / 2, near);
		dstg.vertex(-width / 2, -height / 2, near);
		dstg.vertex(0, 0, 0);
		dstg.endShape();

		dstg.line(width / 2, height / 2, near, -width / 2, -height / 2, near);
		dstg.line(width / 2, -height / 2, near, -width / 2, height / 2, near);

		dstg.popMatrix();
	}
}