/**
 * Just an object to draw grid as a virtual floor
 * @author Yasuto Nakanishi
 */
package net.unitedfield.processinglue;

import processing.core.PApplet;
import processing.opengl.PGraphics3D;

public class PglueFloor {
	int size, lineNum;
	PApplet parentApplet;

	/**
	 * Constructor
	 * @param _size rectangle size of this floor
	 * @param _lineNum number of line of this display
	 * @param _parentApplet the PApplet within this floor is installed.
	 * @return a instance of PglueFloor	
	 */
	public PglueFloor(int _size, int _lineNum, PApplet _parentApplet) {
		this.size = _size;
		this.lineNum = _lineNum;
		this.parentApplet = _parentApplet;
	}

	/**
	 * drawing the grid which center is (0,0,0). 
	 */
	public void draw() {
		parentApplet.stroke(255);
		for (int i = -lineNum / 2; i <= lineNum / 2; i++)
			parentApplet.line(i * size / lineNum, 0, size / 2, i * size / lineNum, 0, -size / 2);
		for (int j = -10; j <= 10; j++)
			parentApplet.line(size / 2, 0, j * size / lineNum, -size / 2, 0, j * size / lineNum);
	}

	/**
	 * drawing the grid to a specified PGraphics3D
	 * @param dstg the destination PGraphics3D
	 */
	public void draw(PGraphics3D dstg) {
		dstg.stroke(255);
		for (int i = -lineNum / 2; i <= lineNum / 2; i++)
			dstg.line(i * size / lineNum, 0, size / 2, i * size / lineNum, 0, -size / 2);
		for (int j = -10; j <= 10; j++)
			dstg.line(size / 2, 0, j * size / lineNum, -size / 2, 0, j * size / lineNum);
	}
}