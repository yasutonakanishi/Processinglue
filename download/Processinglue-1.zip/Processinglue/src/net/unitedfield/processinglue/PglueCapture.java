/**
 *  A virtual camera that works within a 3D PApplet and extends processing.video.Capture class. 
 *  Thus it is easy to use in a PglueDisplay content PApplet, 
 *  and this enables deploy the content PApplet in the real world with a little code revise.
 *  @author Yasuto Nakanishi
 */
package net.unitedfield.processinglue;

import processing.video.Capture;
import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;
import processing.opengl.PGraphics3D;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.lang.Class;

public class PglueCapture extends Capture {
	PApplet parent;
	Object dstObject;
	String dstMethodName;
	Method dstMethod;

	PGraphics3D cameraGraphics;
	PImage cameraImage;
	PVector loc, lookAt, dir;
	PglueFrustum frustum;

	/**
	 * Constructor
	 * 
	 * @param _width
	 *            camera image width
	 * @param _height
	 *            camera image height
	 * @param _parent
	 *            the 3D PApplet within this camera is installed.
	 * @param _graphicsMethodName
	 *            a method of the parent PApplet that draws objects in the
	 *            simulation world.
	 */
	public PglueCapture(int _width, int _height, PApplet _parent, String _graphicsMethodName) {
		super(_parent, _width, _height);

		this.parent = _parent;
		cameraGraphics = (PGraphics3D) parent.createGraphics(_width, _height, PApplet.P3D);
		loc = new PVector(0, 0, 0);
		lookAt = new PVector(0, 0, 0);
		dir = new PVector(0, 0, 0);
		frustum = new PglueFrustum(loc, lookAt, cameraGraphics);
		cameraImage = new PImage(_width, _height);

		// ---
		dstObject = _parent;
		dstMethodName = _graphicsMethodName;
		try {
			dstMethod = dstObject.getClass().getMethod(dstMethodName, new Class[] { PGraphics3D.class });
		} catch (NoSuchMethodException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * set the location of this camera within the parent 3D PApplet.
	 * 
	 * @param _x
	 * @param _y
	 * @param _z
	 */
	public void setLocation(int _x, int _y, int _z) {
		loc.x = _x;
		loc.y = _y;
		loc.z = _z;
		frustum.setLocation(loc.x, loc.y, loc.z);
	}

	/**
	 * set the lookAt point of this camera within the parent 3D PApplet.
	 * 
	 * @param _x
	 * @param _y
	 * @param _z
	 */
	public void setLookAt(int _x, int _y, int _z) {
		lookAt.x = _x;
		lookAt.y = _y;
		lookAt.z = _z;
		frustum.setLookAt(lookAt.x, lookAt.y, lookAt.z);
	}

	/**
	 * intentionally override Capture.init() so that this class doesn't open
	 * GStreamer, and this does nothing because this class is Virtual Capture.
	 */
	protected void initGStreamer(PApplet parent, int rw, int rh, String src, String idName, Object idValue,
			String fps) {
		;
	}

	@Override
	public boolean available() {
		return cameraImage != null;
	}

	@Override
	public void read() {
		cameraGraphics.beginDraw();
		cameraGraphics.camera(loc.x, loc.y, loc.z, // eyeX, eyeY, eyeZ,
				lookAt.x, lookAt.y, lookAt.z, // centerX, centerY, centerZ,
				0, 1, 0); // upX, upY, upZ
		try {
			dstMethod.invoke(dstObject, new Object[] { cameraGraphics });
		} catch (IllegalArgumentException e) {
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			throw new RuntimeException(e);
		} catch (InvocationTargetException e) {
			throw new RuntimeException(e);
		}
		cameraGraphics.endDraw();
		cameraImage = cameraGraphics.get(0, 0, cameraGraphics.width, cameraGraphics.height);	

		// copy cameraImage to pixels
		this.copy(cameraImage, 0, 0, width, height, 0, 0, width, height);
	}

	/**
	 * calling the method to draw the camera frustum to a specified PGraphics3D 
	 * @param dstg
	 */
	public void draw(PGraphics3D dstg) {
		frustum.draw(dstg);
	}
}