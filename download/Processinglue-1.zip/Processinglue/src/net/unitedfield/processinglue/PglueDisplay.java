/**
 * a Vistual Display showing a PApplet within another 3D PApplet.
 * With using PApplet.registerMethod(), the register method is called after draw() in the content PApplet.
 * The method update the content of the PApplet as a PImage, and draw it within the parent 3D PApplet as a rectangle.  
 * @author Yasuto Nakanishi
 */
package net.unitedfield.processinglue;

import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;
import processing.opengl.PGraphics3D;

public class PglueDisplay {
	PApplet parentApplet;
	PApplet contentApplet;
	PImage appletImage;
	PVector loc, rot;
	float dWidth, dHeight;

	/**
	 * Constructor
	 * @param _dWidth width of this display
	 * @param _dHeight height of this display
	 * @param _contentApplet the content to show in this display
	 * @param _parentApplet the 3D PApplet within this dispay is installed.
	 * @return a instance of PglueDisplay	
	 */
	public PglueDisplay(float _dWidth, float _dHeight, ContentPApplet _contentApplet, PApplet _parentApplet) {
		this.parentApplet = _parentApplet;
		this.dWidth = _dWidth;
		this.dHeight = _dHeight;
		this.contentApplet = _contentApplet;
		this.appletImage = new PImage(contentApplet.width, contentApplet.height);
		contentApplet.registerMethod("post", this);

		this.loc = new PVector(0, 0, 0);
		this.rot = new PVector(0, 0, 0);
	}

	/**
	 * This method is registered to the content PApplet, 
	 * and called after draw() in the content PApplet to copy the drawn content.
	 */
	public void post() {
		try {
			this.contentApplet.loadPixels();
			for (int i = 0; i < this.contentApplet.pixels.length; i++) {
				this.appletImage.pixels[i] = this.contentApplet.pixels[i];
			}
			this.appletImage.updatePixels();
		} catch (ArrayIndexOutOfBoundsException aiobe) {
		}
	}

	/**
	 * set the location of this display within the parent 3D PApplet. 
	 * @param _x x of this display location
	 * @param _y y of this display location
	 * @param _z z of this display location
	 */
	public void translate(float _x, float _y, float _z) {
		this.loc.x = _x;
		this.loc.y = _y;
		this.loc.z = _z;
	}

	/**
	 * set the rotation of this display within the parent 3D PApplet. 
	 * @param _x x of this display location
	 * @param _y y of this display location
	 * @param _z z of this display location	
	 */
	public void rotate(float _rx, float _ry, float _rz) {
		this.rot.x = _rx;
		this.rot.y = _ry;
		this.rot.z = _rz;
	}

	/**
	 * set the size of this display within the parent 3D PApplet. 
	 * @param _dWidth width of this display location
	 * @param _dHeight height of this display location
	 */
	public void size(int _dWidth, int _dHeight){
		this.dWidth = _dWidth;
		this.dHeight = _dHeight;
	}
	
	/**
	 * This method is called in the parent 3D PApplet and draws the content of the PApplet.
	 */
	public void draw() {
		PGraphics3D dstP3D = (PGraphics3D) this.parentApplet.g;
		if (dstP3D != null)
			this.draw(dstP3D);
	}
	
	/**
	 * This method is called in the parent 3D PApplet using PglueCapture(a virtual camera).
	 * When using a virtual camera, the content should be drawn into a specified PGraphics3D.
	 * @param _g a destination PGraphics3D to draw the content  
	 */
	public void draw(PGraphics3D _g) {
		_g.pushMatrix();
		_g.translate(loc.x, loc.y, loc.z);
		_g.rotateX(rot.x);
		_g.rotateY(rot.y);
		_g.rotateZ(rot.z);
		drawShape(_g);
		_g.popMatrix();
	}

	/**
	 * This draws the content as a texture of a PShape
	 * @param _g destination PGraphics3D to draw the content  
	 */
	public void drawShape(PGraphics3D _g) {
		_g.beginShape();
		_g.texture(appletImage);
		_g.vertex(-dWidth / 2, -dHeight, 0, 0, 0);
		_g.vertex(dWidth / 2, -dHeight, 0, appletImage.width, 0);
		_g.vertex(dWidth / 2, 0, 0, appletImage.width, appletImage.height);
		_g.vertex(-dWidth / 2, 0, 0, 0, appletImage.height);
		_g.endShape();
	}

	/**	 
	 * return the latest content as a PImage
	 * @return the latest content as a PImage	
	 */
	public PImage getPImage() {
		return this.appletImage;
	}

	/**	 
	 * return the PApplet to show its content
	 * @return the PApplet to show its content
	 */
	public PApplet getApplet() {
		return this.contentApplet;
	}
}